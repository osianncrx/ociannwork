export const FALLBACKS = {
  VideoCalls: false,
  AudioCalls: false,
  AudioMessages: false,
  MaxMessageLength: 40000,
  ScreenSharing: false,
  DefaultThemeMode: 'light',
  sidebar_logo_url: '/logo/placeholder.png',
}

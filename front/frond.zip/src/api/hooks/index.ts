import useApiGet from './useApiGet'
import useApiPost from './useApiPost'

export { useApiGet, useApiPost }

import SenderName from './SenderName'
import UserChatAvatar from './UserChatAvatar'

export { SenderName, UserChatAvatar }

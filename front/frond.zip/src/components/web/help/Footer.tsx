const Footer = () => {
  return <div className="faq-footer text-center py-4">Copyright 2025 © Teamwise template by pixelstrap</div>
}

export default Footer

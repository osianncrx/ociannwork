import { Col, Container, Row } from 'reactstrap'
import { SvgIcon } from '../../../shared/icons'
import { Image } from '../../../shared/image'
import { useAppSelector } from '../../../store/hooks'
import { OnboardingWrapperProps } from '../../../types'

const OnboardingWrapper = ({
  children,
  showBackButton = false,
  onBackClick = () => {},
  wrapperClass = '',
}: OnboardingWrapperProps) => {
  const { onboarding_logo } = useAppSelector((state) => state.publicSetting)
  const { mixBackgroundLayout } = useAppSelector((store) => store.theme)

  return (
    <Container fluid className={`login-wrapper auth-background welcome-card  ${wrapperClass}`}>
      <Row className="g-0 min-vh-100">
        <Col className="common-flex card-flex">
          <div className="login-card text-center">
            <div className="onboarding-wrapper-box">
              {showBackButton && (
                <div className="back-btn-badge" onClick={onBackClick}>
                  <SvgIcon className="back-btn-icon" iconId="back-arrow-icon" />
                </div>
              )}
              <div className="logo">
                {onboarding_logo ? (
                  <Image src={onboarding_logo} alt="ChatLogo" height={35} />
                ) : (
                  <SvgIcon
                    className={`full-logo ${mixBackgroundLayout === 'dark' ? 'dark' : 'light'}`}
                    iconId={`${mixBackgroundLayout === 'dark' ? 'dark-full-logo' : 'light-full-logo'}`}
                  />
                )}
              </div>
              {children}
            </div>
          </div>
        </Col>
      </Row>
    </Container>
  )
}

export default OnboardingWrapper

export type InviteTeamMemberModalProps = {
  isOpen: boolean
  toggle: () => void
}

export interface InviteTeamFormValues {
  emails: string[]
}
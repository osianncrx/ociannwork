const Loader = () => {
  return (
    <div className="custom-page-loader">
      <div className="loader"></div>
    </div>
  )
}

export default Loader

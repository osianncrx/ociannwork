declare module 'simplebar-react' {
  import * as React from 'react'
  export default class SimpleBar extends React.Component<any, any> {}
}

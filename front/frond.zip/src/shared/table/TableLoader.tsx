const TableLoader = () => {
  return (
    <div className="table-loader">
      <div className="loader-wrapper">
        <div className="loader"></div>
      </div>
    </div>
  )
}

export default TableLoader

import SvgIcon from './SvgIcon'

export { SvgIcon }

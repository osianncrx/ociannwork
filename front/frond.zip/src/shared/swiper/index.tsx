import ImageGallery from './ImageGallery'
import { MediaGallery } from './ImageGallery'

export { ImageGallery, MediaGallery }

import Avatar from './Avatar'
import Image from './Image'

export { Avatar, Image }


import { SolidButton } from './SolidButton'

export { SolidButton }
